import { createApp } from 'vue'
import App from './App.vue'

import './service/axios_demo'
import hyRequest from './service'
//全局映入
//import ElementPlus from 'element-plus'
//import 'element-plus/dist/index.css'

import router from './router'
import store from './store'

const app = createApp(App)

app.use(router)
app.use(store)
//app.use(ElementPlus)
app.mount('#app')

hyRequest.request({
  url: '/home/multidata',
  method: 'GET'
})
